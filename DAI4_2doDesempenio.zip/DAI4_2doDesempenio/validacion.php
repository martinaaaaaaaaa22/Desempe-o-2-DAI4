<?php

require 'conexion.php';//Traemos el archivo de la conexion a la base de datos

session_start();//iniciamos la sesion


$Mensaje = "";  // Inicializamos el mensaje

//Funcion para Mostrar Mensaje al Cerrar Sesion
function MensajeSesionCerrada()
{
    // Verifica si el parámetro 'cerrado' está en la URL
    if (isset($_GET['cerrado']) && $_GET['cerrado'] == 'true') {
        $_SESSION['mensaje_inactivo'] = "Sesión cerrada correctamente.";
    }

    // Verificar si hay un mensaje en la sesión y devolverlo
    if (isset($_SESSION['mensaje_inactivo'])) {
        $mensaje = $_SESSION['mensaje_inactivo'];
        unset($_SESSION['mensaje_inactivo']); // Limpiar el mensaje(sesion) después de usarlo
        return $mensaje;//Se muestra el mensaje
    }

    return ""; // Si no hay mensaje, devolver una cadena vacía
}

// Llamamos a la función para obtener el mensaje (si existe)
$Mensaje = MensajeSesionCerrada();


// Función  de validación de campos vacios
function validarCamposVaciosYProcesar($post, $linkconexion)
{
    if (!isset($post['boton_ingreso'])) {
        return null; // Si no se presionó el botón, no se hace nada
    }

    $usuario = trim($post['usuario'] ?? ''); // Elimina espacios en blanco
    $clave = trim($post['clave'] ?? ''); // Elimina espacios en blanco

    // Validamos campos vacíos
    if (empty($usuario) && empty($clave)) {
        return 'Por favor, ingrese ambos campos.';
    }
    if (empty($usuario)) {
        return 'Por favor, ingrese su usuario.';
    }
    if (empty($clave)) {
        return 'Por favor, ingrese su clave.';
    }

    // Validación de usuario y contraseña
    return ValidacionUserPass($usuario, $clave, $linkconexion);
}

// Uso dentro del flujo principal:
$Mensaje = validarCamposVaciosYProcesar($_POST, $linkconexion);


//FUNCION QUE VALIDA EL INGRESO CON USUARIO Y CONTRASEÑA
function ValidacionUserPass($usuario, $clave, $linkconexion)
{
    // VALIDACION DE USUARIO Y CONTRASEÑA
    $Login_usuarios = mysqli_query($linkconexion, "SELECT * FROM usuarios WHERE dni='$usuario' AND clave='$clave'");
    // Toma el dni y la clave del usuario

    if (mysqli_num_rows($Login_usuarios) > 0) {//Sirve para ver si a traves de la consulta encuentra alguna valor que coincida con los datos ingresados

        $datos_user = mysqli_fetch_array($Login_usuarios);//Guarda los datos obtenidos de la consulta en un ARRAY

        if ($datos_user['activo'] != 1) {

            $_SESSION['mensaje_inactivo'] = "Usuario Inactivo.No puede iniciar sesion";

            header("Location:login.php");
            exit;


        } else {
            $_SESSION['usuario'] = $datos_user['dni'];//Guarda los datos del usuario-Mantiene la sesion del usuario iniciada
            //Los datos que se le pasan se guardan en el servidor
            $_SESSION['clave'] = $datos_user['clave'];
            $_SESSION['estado'] = $datos_user['activo'];
            $_SESSION['nivel_user'] = $datos_user['id_nivel'];
            $_SESSION['nombre'] = $datos_user['nombre'];
            $_SESSION['apellido'] = $datos_user['apellido'];
            $_SESSION['imagen'] = $datos_user['imagen'];
            $_SESSION['id_usuario'] = $datos_user['id_usuario'];

            header("Location:index.php");//Redirecciona al usuario al INDEX si es ACTIVO
            exit;
        }
    } else {
        return 'Los datos son incorrectos.Intenta nuevamente.';
    }
}

//FUNCION PARA MOSTRAR EL LISTADO DE VIAJES DEL CHOFER
function MostrarViajesChofer($user_id, $nivel_user, $linkconexion)
{
    if ($nivel_user == 3) {
        // Consulta para el chofer (nivel 3)
        $consulta = "SELECT viajes.*, 
                            destinos.denominacion AS destino_nombre,
                            usuarios.nombre AS nombre_usuario,
                            usuarios.apellido AS apellido_usuario,
                            transportes.patente AS patente_transporte,
                            transportes.modelo AS modelo_transporte,
                            tipos_transporte.tipo_transporte AS tipo_de_transporte
                     FROM viajes
                     LEFT JOIN destinos ON viajes.id_destino = destinos.id_destino
                     LEFT JOIN usuarios ON viajes.id_chofer = usuarios.id_usuario
                     LEFT JOIN transportes ON viajes.id_transporte = transportes.id_transporte
                     LEFT JOIN tipos_transporte ON transportes.id_tipo_transporte = tipos_transporte.id_tipo_transporte
                     WHERE viajes.id_chofer = '$user_id'";

    } else if ($nivel_user == 1 || $nivel_user == 2) {
        //     // Consulta para otros niveles de usuario-Muestra info de los viajes
        $consulta = "SELECT viajes.*, 
                            destinos.denominacion AS destino_nombre,
                            usuarios.nombre AS nombre_usuario,
                            usuarios.apellido AS apellido_usuario,
                            transportes.patente AS patente_transporte,
                            transportes.modelo AS modelo_transporte,
                            tipos_transporte.tipo_transporte AS tipo_de_transporte
                     FROM viajes
                     LEFT JOIN destinos ON viajes.id_destino = destinos.id_destino
                     LEFT JOIN usuarios ON viajes.id_chofer = usuarios.id_usuario
                     LEFT JOIN transportes ON viajes.id_transporte = transportes.id_transporte
                     LEFT JOIN tipos_transporte ON transportes.id_tipo_transporte = tipos_transporte.id_tipo_transporte";
    }


    // Ejecutar la consulta
    $resultado = mysqli_query($linkconexion, $consulta);

    // Verificar si la consulta devolvió resultados
    if (mysqli_num_rows($resultado) > 0) {
        // Obtener todos los resultados en un array asociativo
        $array_viajes = mysqli_fetch_all($resultado, MYSQLI_ASSOC);
        //MYSQLI_ASSOC- Tomas las filas obtenidas de una consulta y las guarda en un array y se las recorre como con un foreach
        //Cada campo clave es el nombre de la columna,entonces si no se utiliza no puedo acceder a 
        //ID ya que en vez de ingresar a ID tendremos que acceder con su indice exacto.
        return $array_viajes;
    } else {
        return null;  // Si no hay resultados, devolver null
    }
}


//Funcion para mostrar nivel del usuario en su perfil
function MostrarNIvelFtoPerfil($nivel_user)
{
    switch ($nivel_user) {
        case 1:
            return 'Administrador';

        case 2:
            return 'Operador';
        case 3:
            return 'Chofer';
    }
}

?>