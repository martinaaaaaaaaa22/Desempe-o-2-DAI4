<?php
//Conexion a la Base de Datos

$Host="localhost";
$User="root";
$Password="";
$BaseDeDatos="parcial2-dai";

$linkconexion= mysqli_connect($Host,$User,$Password,$BaseDeDatos);
//Permite realizar la conexion con la base de datos. Devuelve como valor TRUE o FALSE

// if($linkconexion!=false){
//     echo '<H3>CONECTADO CORRECTAMENTE</H3>';
// }else{
//     echo '<H3>HUBO ERROR EN LA CONEXION</H3>';
// }




?>