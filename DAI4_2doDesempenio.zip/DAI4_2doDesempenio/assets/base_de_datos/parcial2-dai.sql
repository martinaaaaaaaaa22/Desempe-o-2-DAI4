-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1:3306
-- Tiempo de generación: 16-11-2024 a las 14:45:42
-- Versión del servidor: 8.3.0
-- Versión de PHP: 8.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `parcial2-dai`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `destinos`
--

DROP TABLE IF EXISTS `destinos`;
CREATE TABLE IF NOT EXISTS `destinos` (
  `id_destino` int NOT NULL AUTO_INCREMENT,
  `denominacion` varchar(255) NOT NULL,
  PRIMARY KEY (`id_destino`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `destinos`
--

INSERT INTO `destinos` (`id_destino`, `denominacion`) VALUES
(1, 'Córdoba Capital'),
(2, 'Río Cuarto'),
(3, 'Villa María'),
(4, 'Villa Carlos Paz'),
(5, 'Alta Gracia'),
(6, 'San Francisco'),
(7, 'Mina Clavero'),
(8, 'La Falda'),
(9, 'Embalse'),
(10, 'Cosquín');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `marcas`
--

DROP TABLE IF EXISTS `marcas`;
CREATE TABLE IF NOT EXISTS `marcas` (
  `id_marca` int NOT NULL AUTO_INCREMENT,
  `denominacion` varchar(255) NOT NULL,
  PRIMARY KEY (`id_marca`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `marcas`
--

INSERT INTO `marcas` (`id_marca`, `denominacion`) VALUES
(1, 'Mercedes-Benz'),
(2, 'Volkswagen'),
(3, 'Ford'),
(4, 'Chevrolet'),
(5, 'Renault'),
(6, 'Fiat'),
(7, 'Peugeot'),
(8, 'Toyota'),
(9, 'Honda'),
(10, 'Citroën');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `niveles_usuarios`
--

DROP TABLE IF EXISTS `niveles_usuarios`;
CREATE TABLE IF NOT EXISTS `niveles_usuarios` (
  `id_nivel` int NOT NULL AUTO_INCREMENT,
  `Nivel` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_nivel`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `niveles_usuarios`
--

INSERT INTO `niveles_usuarios` (`id_nivel`, `Nivel`) VALUES
(1, 'Admin'),
(2, 'Operador'),
(3, 'Chofer');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipos_transporte`
--

DROP TABLE IF EXISTS `tipos_transporte`;
CREATE TABLE IF NOT EXISTS `tipos_transporte` (
  `id_tipo_transporte` int NOT NULL AUTO_INCREMENT,
  `tipo_transporte` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_tipo_transporte`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `tipos_transporte`
--

INSERT INTO `tipos_transporte` (`id_tipo_transporte`, `tipo_transporte`) VALUES
(1, 'Camión'),
(2, 'Furgón'),
(3, 'Camioneta'),
(4, 'Micro');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `transportes`
--

DROP TABLE IF EXISTS `transportes`;
CREATE TABLE IF NOT EXISTS `transportes` (
  `id_transporte` int NOT NULL AUTO_INCREMENT,
  `id_marca` int DEFAULT NULL,
  `id_tipo_transporte` int DEFAULT NULL,
  `patente` varchar(10) NOT NULL,
  `modelo` varchar(255) NOT NULL,
  `disponible` tinyint(1) DEFAULT NULL,
  `combustible` varchar(100) DEFAULT NULL,
  `fecha_carga` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id_transporte`),
  UNIQUE KEY `patente` (`patente`),
  KEY `id_marca` (`id_marca`),
  KEY `id_tipo_transporte` (`id_tipo_transporte`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `transportes`
--

INSERT INTO `transportes` (`id_transporte`, `id_marca`, `id_tipo_transporte`, `patente`, `modelo`, `disponible`, `combustible`, `fecha_carga`) VALUES
(1, 1, 1, 'ABC123', 'Actros 2545', 1, 'Gasoil', '2024-11-14 03:00:00'),
(2, 2, 2, 'DEF456', 'Transporter T6', 1, 'GNC', '2024-11-13 03:00:00'),
(3, 3, 3, 'GHI789', 'Ranger 2.2', 0, 'Nafta', '2024-11-12 03:00:00'),
(4, 2, 4, 'ADC123', 'Ranger', 1, 'Gasoil', '2024-11-14 03:00:00'),
(5, 5, 3, 'JKLM456', 'Daily 35S14', 1, 'GNC', '2024-11-11 03:00:00'),
(6, 7, 2, 'UVWX567', 'Ducato Maxi', 1, 'Gasoil', '2024-11-07 03:00:00'),
(7, 8, 1, 'YZAB890', 'Amarok V6', 0, 'Nafta', '2024-11-08 03:00:00'),
(8, 10, 4, 'NOP789', 'Daily 35S14', 1, 'GNC', '2024-11-10 03:00:00'),
(9, 8, 2, 'KXY 015', 'Amarok V6', 1, 'GNC', '2024-11-20 03:00:00'),
(10, 6, 2, 'UWI 230', 'Actros 2545', 1, 'Gasoil', '2021-01-01 03:00:00');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE IF NOT EXISTS `usuarios` (
  `id_usuario` int NOT NULL AUTO_INCREMENT,
  `apellido` varchar(255) NOT NULL,
  `nombre` varchar(255) NOT NULL,
  `dni` varchar(20) NOT NULL,
  `clave` varchar(255) NOT NULL,
  `activo` tinyint(1) DEFAULT NULL,
  `id_nivel` int DEFAULT NULL,
  `fecha_creacion` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `imagen` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_usuario`),
  UNIQUE KEY `dni` (`dni`),
  KEY `id_nivel` (`id_nivel`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id_usuario`, `apellido`, `nombre`, `dni`, `clave`, `activo`, `id_nivel`, `fecha_creacion`, `imagen`) VALUES
(1, 'González', 'Pedro', '12345678', 'clave123', 0, 1, '2024-11-14 03:00:00', 'bellota.jpg'),
(2, 'López', 'Ana', '23456789', 'clave234', 1, 2, '2024-11-13 03:00:00', 'messages-1.jpg'),
(3, 'Martínez', 'Carlos', '34567890', 'clave345', 1, 3, '2024-11-12 03:00:00', 'messages-2.jpg'),
(4, 'Martínez', 'Lucas', '33221144', 'clave346', 1, 1, '2024-11-15 03:00:00', 'messages-3.jpg'),
(5, 'Rodriguez', 'Marcos', '44556677', 'clave321', 1, 3, '2024-11-16 02:58:15', 'profile-img.jpg');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `viajes`
--

DROP TABLE IF EXISTS `viajes`;
CREATE TABLE IF NOT EXISTS `viajes` (
  `id_viaje` int NOT NULL AUTO_INCREMENT,
  `id_chofer` int DEFAULT NULL,
  `id_transporte` int DEFAULT NULL,
  `fecha_pauta` date NOT NULL,
  `id_destino` int DEFAULT NULL,
  `fecha_creacion` timestamp NULL DEFAULT NULL,
  `id_registrante` int DEFAULT NULL,
  `costo` decimal(10,2) DEFAULT NULL,
  `porcentaje_chofer` decimal(5,2) DEFAULT NULL,
  PRIMARY KEY (`id_viaje`),
  KEY `id_chofer` (`id_chofer`),
  KEY `id_transporte` (`id_transporte`),
  KEY `id_destino` (`id_destino`),
  KEY `id_registrante` (`id_registrante`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Volcado de datos para la tabla `viajes`
--

INSERT INTO `viajes` (`id_viaje`, `id_chofer`, `id_transporte`, `fecha_pauta`, `id_destino`, `fecha_creacion`, `id_registrante`, `costo`, `porcentaje_chofer`) VALUES
(1, 3, 2, '2024-11-15', 1, '2024-11-14 03:00:00', 1, 2500.00, 10.00),
(2, 4, 3, '2024-11-16', 2, '2024-11-15 03:00:00', 2, 3000.00, 12.00),
(3, 3, 4, '2024-11-17', 3, '2024-11-16 03:00:00', 1, 2000.00, 8.00),
(4, 3, 5, '2024-11-18', 4, '2024-11-17 03:00:00', 3, 3500.00, 15.00),
(5, 4, 6, '2024-11-19', 5, '2024-11-18 03:00:00', 2, 4000.00, 20.00),
(6, 3, 7, '2024-11-20', 6, '2024-11-19 03:00:00', 1, 4500.00, 18.00),
(7, 4, 8, '2024-11-21', 7, '2024-11-20 03:00:00', 4, 2800.00, 10.00),
(8, 3, 8, '2024-11-22', 8, '2024-11-21 03:00:00', 3, 5000.00, 25.00),
(9, 4, 10, '2024-11-23', 9, '2024-11-22 03:00:00', 2, 3200.00, 11.00),
(10, 3, 1, '2024-11-24', 10, '2024-11-23 03:00:00', 4, 3800.00, 13.00),
(11, 5, 2, '2021-01-01', 2, '2021-01-01 03:00:00', 1, 300.00, 20.00);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
